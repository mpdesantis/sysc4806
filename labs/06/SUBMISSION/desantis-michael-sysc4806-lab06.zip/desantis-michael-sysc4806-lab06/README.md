# README
* Author: Michael De Santis
* CUID: 101213450
* Date: 2024/10/28
* Submission: SYSC 4101 A Lab 6

## Description
SYSC 4806A Lab 6 Submission.

## Configuration
The code submitted here was developed and compiled on an Ubuntu 22.04 LTS machine with the folowing Java versions:
```bash
$ java --version
openjdk 21.0.4 2024-07-16
OpenJDK Runtime Environment (build 21.0.4+7-Ubuntu-1ubuntu222.04)
OpenJDK 64-Bit Server VM (build 21.0.4+7-Ubuntu-1ubuntu222.04, mixed mode, sharing)
```

## Notes
Thanks!!

