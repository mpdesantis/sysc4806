package com.example.accessing_data_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
